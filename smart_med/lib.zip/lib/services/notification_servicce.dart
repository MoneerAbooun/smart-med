import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  static final FlutterLocalNotificationsPlugin
  _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  static bool _isInitialized = false;
  static final Random _random = Random();

  static const AndroidNotificationDetails _androidDetails =
      AndroidNotificationDetails(
        'med_channel',
        'Medication Reminders',
        channelDescription: 'Medication reminder notifications',
        importance: Importance.max,
        priority: Priority.high,
      );

  static const NotificationDetails _notificationDetails = NotificationDetails(
    android: _androidDetails,
  );

  static Future<void> init() async {
    if (_isInitialized) return;

    tz.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Hebron'));

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings settings = InitializationSettings(
      android: androidSettings,
    );

    await _flutterLocalNotificationsPlugin.initialize(settings);
    _isInitialized = true;
  }

  static Future<bool> requestPermission() async {
    final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
        _flutterLocalNotificationsPlugin
            .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin
            >();

    final bool? granted = await androidImplementation
        ?.requestNotificationsPermission();

    return granted ?? false;
  }

  static Future<void> showInstantNotification({
    required String title,
    required String body,
  }) async {
    await _flutterLocalNotificationsPlugin.show(
      generateNotificationId(),
      title,
      body,
      _notificationDetails,
    );
  }

  static int generateNotificationId() {
    final int timestamp = DateTime.now().millisecondsSinceEpoch % 1000000;
    final int randomPart = _random.nextInt(999);
    return int.parse('$timestamp$randomPart'.substring(0, 9));
  }

  static Future<void> scheduleDailyMedicationReminder({
    required int id,
    required String medicineName,
    required String timeString,
    String? body,
  }) async {
    final TimeOfDay parsedTime = _parseTimeString(timeString);
    final tz.TZDateTime scheduledDate = _nextInstanceOfTime(parsedTime);

    await _flutterLocalNotificationsPlugin.zonedSchedule(
      id,
      'Medication Reminder',
      body ?? 'Time to take $medicineName',
      scheduledDate,
      _notificationDetails,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<List<int>> scheduleMedicationReminders({
    required String medicineName,
    required List<String> times,
    String? body,
  }) async {
    final List<int> notificationIds = [];

    for (final time in times) {
      try {
        final int id = generateNotificationId();

        await scheduleDailyMedicationReminder(
          id: id,
          medicineName: medicineName,
          timeString: time,
          body: body,
        );

        notificationIds.add(id);
      } catch (e) {
        debugPrint('Failed to schedule reminder for time "$time": $e');
      }
    }

    return notificationIds;
  }

  static Future<void> cancelNotification(int id) async {
    await _flutterLocalNotificationsPlugin.cancel(id);
  }

  static Future<void> cancelNotifications(List<dynamic> ids) async {
    for (final dynamic id in ids) {
      final int? parsedId = _toInt(id);
      if (parsedId != null) {
        await _flutterLocalNotificationsPlugin.cancel(parsedId);
      }
    }
  }

  static Future<void> cancelAllNotifications() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
  }

  static TimeOfDay _parseTimeString(String timeString) {
    final String value = timeString.trim().toUpperCase();

    final RegExp regex = RegExp(r'^(\d{1,2}):(\d{2})\s?(AM|PM)$');
    final Match? match = regex.firstMatch(value);

    if (match == null) {
      throw FormatException('Invalid time format: $timeString');
    }

    int hour = int.parse(match.group(1)!);
    final int minute = int.parse(match.group(2)!);
    final String period = match.group(3)!;

    if (hour < 1 || hour > 12 || minute < 0 || minute > 59) {
      throw FormatException('Invalid time value: $timeString');
    }

    if (period == 'PM' && hour != 12) {
      hour += 12;
    } else if (period == 'AM' && hour == 12) {
      hour = 0;
    }

    return TimeOfDay(hour: hour, minute: minute);
  }

  static tz.TZDateTime _nextInstanceOfTime(TimeOfDay time) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);

    tz.TZDateTime scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );

    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    return scheduledDate;
  }

  static int? _toInt(dynamic value) {
    if (value is int) return value;
    if (value is String) return int.tryParse(value);
    return null;
  }

  static Future<void> printPendingNotifications() async {
    final pending = await _flutterLocalNotificationsPlugin
        .pendingNotificationRequests();

    debugPrint('Pending count: ${pending.length}');

    for (final item in pending) {
      debugPrint(
        'Pending -> id: ${item.id}, title: ${item.title}, body: ${item.body}',
      );
    }
  }
}
