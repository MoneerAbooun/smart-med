import 'package:flutter/material.dart';

class Setting extends StatefulWidget {
  final VoidCallback onEditProfileTap;
  final bool isDark;
  final ValueChanged<bool> onThemeChanged;

  const Setting({
    super.key,
    required this.onEditProfileTap,
    required this.isDark,
    required this.onThemeChanged,
  });

  @override
  State<Setting> createState() => _SettingState();
}

class _SettingState extends State<Setting> {
  bool notificationsEnabled = true;

  Widget buildSettingItem({
    required IconData icon,
    required String title,
    VoidCallback? onTap,
    Widget? trailing,
  }) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListTile(
        leading: Icon(icon, color: colorScheme.onSurface),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w600,
            color: colorScheme.onSurface,
          ),
        ),
        trailing:
            trailing ??
            Icon(
              Icons.arrow_forward_ios,
              size: 18,
              color: colorScheme.onSurfaceVariant,
            ),
        onTap: onTap,
      ),
    );
  }

  void showSimpleDialogBox(String title, String content) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(title),
          content: Text(content),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 70,
          title: const Padding(
            padding: EdgeInsets.only(top: 10),
            child: Text(
              "Smart Med",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
          ),
        ),
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 25,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Text(
                          "Settings",
                          style: Theme.of(context).textTheme.headlineSmall
                              ?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: colorScheme.onSurface,
                              ),
                        ),
                      ),
                      const SizedBox(height: 25),
                      buildSettingItem(
                        icon: Icons.person_outline,
                        title: "Edit Profile",
                        onTap: widget.onEditProfileTap,
                      ),
                      buildSettingItem(
                        icon: widget.isDark
                            ? Icons.dark_mode_outlined
                            : Icons.light_mode_outlined,
                        title: "Dark Mode",
                        trailing: Switch(
                          value: widget.isDark,
                          onChanged: widget.onThemeChanged,
                        ),
                      ),
                      buildSettingItem(
                        icon: Icons.notifications_none,
                        title: "Notification Settings",
                        trailing: Switch(
                          value: notificationsEnabled,
                          onChanged: (value) {
                            setState(() {
                              notificationsEnabled = value;
                            });
                          },
                        ),
                      ),
                      buildSettingItem(
                        icon: Icons.info_outline,
                        title: "About Us",
                        onTap: () {
                          showSimpleDialogBox(
                            "About Us",
                            "Smart Med is a smart medication assistant project that helps users manage medicines, reminders, and drug information.",
                          );
                        },
                      ),
                      buildSettingItem(
                        icon: Icons.contact_mail_outlined,
                        title: "Contact Us",
                        onTap: () {
                          showSimpleDialogBox(
                            "Contact Us",
                            "Email: smartmed@app.com\nPhone: +000 000 000 000",
                          );
                        },
                      ),
                      buildSettingItem(
                        icon: Icons.language,
                        title: "Language",
                        onTap: () {
                          showSimpleDialogBox(
                            "Language",
                            "Language setting will be added later.",
                          );
                        },
                      ),
                      buildSettingItem(
                        icon: Icons.help_outline,
                        title: "Help",
                        onTap: () {
                          showSimpleDialogBox(
                            "Help",
                            "This section will include help and FAQ later.",
                          );
                        },
                      ),
                      buildSettingItem(
                        icon: Icons.system_update_alt,
                        title: "App Version",
                        onTap: () {
                          showSimpleDialogBox(
                            "App Version",
                            "Smart Med v1.0.0",
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
