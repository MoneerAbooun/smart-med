import 'dart:io';
import 'package:flutter/material.dart';

class DrugDetailPage extends StatelessWidget {
  final String searchedDrugName;
  final String? imagePath;

  const DrugDetailPage({
    super.key,
    required this.searchedDrugName,
    this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final String displayDrugName = searchedDrugName.trim().isNotEmpty
        ? searchedDrugName.trim()
        : 'Detected Medicine';

    final bool hasImage = imagePath != null && imagePath!.isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 70,
        title: const Padding(
          padding: EdgeInsets.only(top: 10),
          child: Text(
            'Drug Details',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Column(
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 62,
                              height: 62,
                              decoration: BoxDecoration(
                                color: colorScheme.secondaryContainer,
                                borderRadius: BorderRadius.circular(18),
                              ),
                              child: Icon(
                                Icons.medication_outlined,
                                size: 34,
                                color: colorScheme.onSecondaryContainer,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    displayDrugName,
                                    style: theme.textTheme.titleLarge,
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    hasImage
                                        ? 'Medicine selected from camera or gallery'
                                        : 'Medicine selected from search field',
                                    style: theme.textTheme.bodyMedium?.copyWith(
                                      color: colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        if (hasImage) ...[
                          const SizedBox(height: 18),
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              boxShadow: [
                                BoxShadow(
                                  blurRadius: 10,
                                  color: Colors.black26,
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: AspectRatio(
                                aspectRatio: 16 / 9,
                                child: Image.file(
                                  File(imagePath!),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                _DetailBox(
                  title: 'Generic Name',
                  icon: Icons.science_outlined,
                  content: 'Sample generic name for the selected medicine.',
                ),
                const SizedBox(height: 14),

                _DetailBox(
                  title: 'Drug Category',
                  icon: Icons.category_outlined,
                  content: 'Antibiotic / Pain Relief / Supplement placeholder.',
                ),
                const SizedBox(height: 14),

                _DetailBox(
                  title: 'Uses',
                  icon: Icons.healing_outlined,
                  content:
                      'This section will show the main medical uses of the drug after connecting the backend.',
                ),
                const SizedBox(height: 14),

                _DetailBox(
                  title: 'Recommended Dose',
                  icon: Icons.monitor_weight_outlined,
                  content:
                      'Dose information will appear here depending on age, weight, and condition.',
                ),
                const SizedBox(height: 14),

                _DetailBox(
                  title: 'Side Effects',
                  icon: Icons.warning_amber_rounded,
                  content:
                      'Common side effects and important warnings will be displayed here.',
                ),
                const SizedBox(height: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DetailBox extends StatelessWidget {
  final String title;
  final String content;
  final IconData icon;

  const _DetailBox({
    required this.title,
    required this.content,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: colorScheme.primary),
              const SizedBox(width: 6),
              Text(
                title,
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: colorScheme.onSurface,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: colorScheme.surface.withValues(alpha: 0.45),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: colorScheme.outlineVariant),
            ),
            child: Text(
              content,
              style: TextStyle(
                height: 1.4,
                fontSize: 15,
                color: colorScheme.onSurface,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
