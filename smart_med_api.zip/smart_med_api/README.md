# Smart Med FastAPI Starter

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Test
```bash
curl "http://127.0.0.1:8000/drug-details?name=paracetamol"
```
