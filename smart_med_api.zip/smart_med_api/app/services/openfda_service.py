from __future__ import annotations

import httpx

OPENFDA_BASE_URL = "https://api.fda.gov/drug/label.json"


def _first_list_value(record: dict, key: str) -> list[str]:
    value = record.get(key, [])
    if isinstance(value, list):
        return [str(item) for item in value if item]
    return []


async def get_label_by_generic_or_brand_name(name: str) -> dict | None:
    query = f'openfda.generic_name:"{name}" OR openfda.brand_name:"{name}"'
    params = {"search": query, "limit": 1}

    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(OPENFDA_BASE_URL, params=params)
        if response.status_code == 404:
            return None
        response.raise_for_status()
        data = response.json()

    results = data.get("results", [])
    return results[0] if results else None


def extract_label_sections(record: dict) -> dict[str, list[str]]:
    openfda = record.get("openfda", {}) if isinstance(record, dict) else {}

    generic_name = _first_list_value(openfda, "generic_name")
    brand_names = _first_list_value(openfda, "brand_name")
    active_ingredients = (
    _first_list_value(record, "active_ingredient")
    or _first_list_value(openfda, "substance_name")
    or _first_list_value(openfda, "generic_name")
)
    uses = _first_list_value(record, "indications_and_usage") or _first_list_value(record, "purpose")
    warnings = (
        _first_list_value(record, "warnings")
        or _first_list_value(record, "boxed_warning")
        or _first_list_value(record, "warnings_and_cautions")
    )
    side_effects = _first_list_value(record, "adverse_reactions") or _first_list_value(record, "stop_use")
    dosage_notes = _first_list_value(record, "dosage_and_administration") or _first_list_value(record, "dosage_forms_and_strengths")
    contraindications = _first_list_value(record, "contraindications")

    return {
        "generic_name": generic_name,
        "brand_names": brand_names,
        "active_ingredients": active_ingredients,
        "uses": uses,
        "warnings": warnings,
        "side_effects": side_effects,
        "dosage_notes": dosage_notes,
        "contraindications": contraindications,
    }
