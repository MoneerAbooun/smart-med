from fastapi import FastAPI

from app.routers.drug_details import router as drug_details_router

app = FastAPI(
    title="Smart Med API",
    version="0.1.0",
    description="Starter backend for real drug detail lookup.",
)

app.include_router(drug_details_router)


@app.get("/")
async def root() -> dict[str, str]:
    return {"message": "Smart Med API is running"}
